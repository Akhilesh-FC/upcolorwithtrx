<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class BetController extends Controller
{

//======================BET===========================//
// public function Bet(Request $request)
// {
//     $kolkataTime = Carbon::now('Asia/Kolkata');
//     $formattedTime = $kolkataTime->toDateTimeString();

//     $validator = Validator::make($request->all(),[
//         'user_id' => 'required',
//         'game_id' => 'required',
//         'amount' => 'required|numeric|min:1',
//     ])->stopOnFirstFailure();

//     if ($validator->fails()){
//         return response()->json(['success' => false, 'message' => $validator->errors()->first()], 200);
//     }

//     $userId = $request->user_id;
//     $gameId = $request->game_id;
//     $amount = $request->amount;

//     $userWallet = DB::table('user')->where('id', $userId)->value('wallet');
//     if ($userWallet < $amount){
//         return response()->json(['success' => false, 'message' => 'Insufficient balance'], 200);
//     }

//     $periodNo = DB::table('betlogs')->value('period_no');
//     DB::table('bets')->insert([
//         'user_id' => $userId,
//         'game_id' => $gameId,
//         'amount' => $amount,
//         // 'period_no' => $periodNo,
//         'status' => 0,
//         'created_at' => $formattedTime,
//         'updated_at' => $formattedTime,
//     ]);

//     DB::table('user')
//         ->where('id', $userId)
//         ->update(['wallet' => DB::raw("wallet - $amount")]);
//     $multiplier = DB::table('game_settings')
//         ->where('game_id', $gameId)
//         ->value('multiplier');

//     $betLogs = DB::table('betlogs')->get();
//     foreach ($betLogs as $row){
//         $gameIdArray = json_decode($row->game_id, true);
//         if (is_array($gameIdArray) && in_array($gameId, $gameIdArray)) {
//             $number = $row->number;
//             $multiplyAmount = $amount * $multiplier;
//             DB::table('betlogs')
//                 ->where('number', $number)
//                 ->update([
//                     'amount' => DB::raw("amount + $multiplyAmount")
//                 ]);
//          }
//     }
//     return response()->json(['success' => true, 'message' => 'Bet Accepted Successfully!'], 200);
//  } 
 
 public function Bet(Request $request)
{
    $kolkataTime = Carbon::now('Asia/Kolkata');
    $formattedTime = $kolkataTime->toDateTimeString();

    $validator = Validator::make($request->all(), [
        'user_id' => 'required',
        'game_id' => 'required',
        'amount' => 'required|numeric|min:1',
    ])->stopOnFirstFailure();

    if ($validator->fails()) {
        return response()->json(['success' => false, 'message' => $validator->errors()->first()], 200);
    }

    $userId = $request->user_id;
    $gameId = $request->game_id;
    $amount = $request->amount;

    // $gameExists = DB::table('games')->where('id', $gameId)->exists();
    // if (!$gameExists) {
    //     return response()->json(['success' => false, 'message' => 'Invalid Game ID'], 200);
    // }

    $userWallet = DB::table('user')->where('id', $userId)->value('wallet');
    if ($userWallet < $amount) {
        return response()->json(['success' => false, 'message' => 'Insufficient balance'], 200);
    }

    $periodNo = DB::table('betlogs')->value('period_no');
    DB::table('bets')->insert([
        'user_id' => $userId,
        'game_id' => $gameId,
        'amount' => $amount,
        // 'period_no' => $periodNo,
        'status' => 0,
        'created_at' => $formattedTime,
        'updated_at' => $formattedTime,
    ]);

    DB::table('user')
        ->where('id', $userId)
        ->update(['wallet' => DB::raw("wallet - $amount")]);

    $multiplier = DB::table('game_settings')
        ->where('game_id', $gameId)
        ->value('multiplier');

    $betLogs = DB::table('betlogs')->get();
    foreach ($betLogs as $row) {
        $gameIdArray = json_decode($row->game_id, true);
        if (is_array($gameIdArray) && in_array($gameId, $gameIdArray)) {
            $number = $row->number;
            $multiplyAmount = $amount * $multiplier;
            DB::table('betlogs')
                ->where('number', $number)
                ->update([
                    'amount' => DB::raw("amount + $multiplyAmount")
                ]);
        }
    }

    return response()->json(['success' => true, 'message' => 'Bet Accepted Successfully!'], 200);
}

 
public function Bets(Request $request)
{
    $kolkataTime = Carbon::now('Asia/Kolkata');
    $formattedTime = $kolkataTime->toDateTimeString();

    $validator = Validator::make($request->all(),[
        'user_id' => 'required',
        'game_id' => 'required',
        'amount' => 'required|numeric|min',
    ])->stopOnFirstFailure();

    if ($validator->fails()){
        return response()->json(['success' => false, 'message' => $validator->errors()->first()], 200);
    }

    $userId = $request->user_id;
    $gameId = $request->game_id;
    $amount = $request->amount;
    $userWallet = DB::table('user')->where('id', $userId)->value('wallet');
    if ($userWallet < $amount) {
        return response()->json(['success' => false, 'message' => 'Insufficient balance'], 200);
    }
    DB::table('bets')->insert([
        'user_id' => $userId,
        'game_id' => $gameId,
        'amount' => $amount,
        'status' => 0,
        'created_at' => $formattedTime,
        'updated_at' => $formattedTime,
    ]);
    DB::table('user')
        ->where('id', $userId)
        ->update(['wallet' => DB::raw("wallet - $amount")]);

    return response()->json(['success' => true, 'message' => 'Bet placed successfully!'], 200);
}


//==============================BET HISTORY==================================//
// public function BetHistory(Request $request)
// {
//     $validator = Validator::make($request->all(),[
//         'user_id' => 'required|integer',
//         'limit' => 'nullable|integer',
//         'offset' => 'nullable|integer'
//     ])->stopOnFirstFailure();

//     if ($validator->fails()){
//         return response()->json([
//             'success' => false,
//             'message' => $validator->errors()->first()
//         ], 200);
//     }

//     $userId = $request->user_id;
//     $limit = $request->limit ??10;
//     $offset = $request->offset ?? 0;

//     $betHistory = DB::table('bets')
//         ->where('user_id', $userId) 
//         ->select('amount','win_amount','multiplier','created_at')
//         ->orderByDesc('bets.id')
//         ->offset($offset)
//         ->limit($limit)
//         ->get();

//     $totalCount = DB::table('bets')
//         ->where('user_id', $userId)
//         ->count();

//     if ($betHistory->isNotEmpty()){
//         return response()->json([
//             'success' => true,
//             'message' => 'Data found',
//             'total_count' => $totalCount,
//             'data' => $betHistory
//         ]);
//     }else{
//         return response()->json([
//             'success' => false,
//             'message' => 'No record found',
//             'data' => []
//         ]);
//     }
// }

public function BetHistory(Request $request)
{
    $validator = Validator::make($request->all(), [
        'user_id' => 'required|integer'
    ])->stopOnFirstFailure();

    if ($validator->fails()) {
        return response()->json([
            'success' => false,
            'message' => $validator->errors()->first()
        ], 200);
    }

    $userId = $request->user_id;

    $betHistory = DB::table('bets')
        ->where('user_id', $userId)
        ->select('amount', 'win_amount', 'multiplier', 'created_at')
        ->orderByDesc('bets.id')
        ->get();

    $totalCount = $betHistory->count();

    if ($betHistory->isNotEmpty()) {
        return response()->json([
            'success' => true,
            'message' => 'Data found',
            'total_count' => $totalCount,
            'data' => $betHistory
        ]);
    } else {
        return response()->json([
            'success' => false,
            'message' => 'No record found',
            'data' => []
        ]);
    }
}


//===========================Cashout================================//
// public function cashout(Request $request){
//     $validator = Validator::make($request->all(), [
//         'multiplier_id' => 'nullable',
//         'game_id' => 'required',
//         'userid' => 'required',
//     ]);

//     if ($validator->fails()){
//         return response()->json([
//             'status' => false,
//             'message' => $validator->errors()->first()
//         ], 200);
//     }
 
//     $cashout_info = DB::table('multiplier')->where('id', $request->multiplier_id)->first();
//     if (!$cashout_info){
//         return response()->json([
//             'status' => false,
//             'message' => 'Multiplier not found.'
//         ], 200);
//     }

//     $cashout_value = $cashout_info->multiplier; 
//     $bet = DB::table('bets')
//         ->where('game_id', $request->game_id)
//         ->where('user_id', $request->userid)
//          ->orderBy('id', 'desc')
//         ->first();

//     if (!$bet){
//         return response()->json([
//             'status' => false,
//             'message' => 'Bet not found for this user and game.'
//         ], 200);
//     }

//   $latestBet = DB::table('bets')
//     ->where('game_id', $request->game_id)
//     ->where('user_id', $request->userid)
//     ->orderBy('id', 'desc') 
//     ->first();

// $alreadyCashedOut = false;

// if ($latestBet && $latestBet->multiplier == $cashout_value && $latestBet->cashout_status == 1) {
//     $alreadyCashedOut = true;
// }


//     if($alreadyCashedOut){
//         return response()->json([
//             'status' => false,
//             'message' => 'Cashout already done on this multiplier.'
//         ], 200);
//     }

//     $multipliedAmount = $bet->amount * $cashout_value; 
//     $user = DB::table('user')->where('id', $request->userid)->first();
//     if (!$user) {
//         return response()->json([
//             'status' => false,
//             'message' => 'User not found.'
//         ], 200);
//     }
 
//     if ($user->wallet < $bet->amount) {
//         return response()->json([
//             'status' => false,
//             'message' => 'Insufficient wallet balance.'
//         ], 200);
//     }

   
//     DB::beginTransaction();
//     try { 
//         DB::table('bets')
//             ->where('id', $bet->id)
//             ->update([
//                 'win_amount' => $multipliedAmount,
//                 'multiplier' => $cashout_value,
//                 'cashout_status' => 1,
//                 'status' => 1,
//                 'updated_at' => now()
//             ]);
 
//         DB::table('user')
//             ->where('id', $request->userid)
//             ->decrement('wallet', $bet->amount); 
//         DB::table('user')
//             ->where('id', $request->userid)
//             ->increment('win_wallet', $multipliedAmount);

//         DB::commit();

//         return response()->json([
//               'status' => true,
//               'message' => 'Cashout processed successfully.',
//              'win_amount' => $multipliedAmount
//         ]);
//     } catch (\Exception $e) {
//         DB::rollBack();
//         return response()->json([
//             'status' => false,
//             'message' => 'Something went wrong during cashout.',
//             'error' => $e->getMessage()
//         ], 200);
//     }
// }

public function cashout(Request $request)
{
    $validator = Validator::make($request->all(), [
        'multiplier_id' => 'nullable',
        'game_id' => 'required',
        'userid' => 'required',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'message' => $validator->errors()->first()
        ], 200);
    }

    $cashout_info = DB::table('multiplier')
        ->where('multiplier', $request->multiplier_id)
        ->first();

    if (!$cashout_info) {
        return response()->json([
            'status' => false,
            'message' => 'Multiplier not found.'
        ], 200);
    }

    $cashout_value = $cashout_info->multiplier;

    // Get latest bet for the user in this game
    $bet = DB::table('bets')
        ->where('game_id', $request->game_id)
        ->where('user_id', $request->userid)
        ->orderBy('id', 'desc')
        ->first();

    if (!$bet) {
        return response()->json([
            'status' => false,
            'message' => 'Bet not found for this user and game.'
        ], 200);
    }

    // Check if already cashed out
    $alreadyCashedOut = false;

    if ($bet && $bet->multiplier == $cashout_value && $bet->cashout_status == 1) {
        $alreadyCashedOut = true;
    }

    if ($alreadyCashedOut) {
        return response()->json([
            'status' => false,
            'message' => 'Cashout already done on this multiplier.'
        ], 200);
    }

    $multipliedAmount = $bet->amount * $cashout_value;

    // Check user
    $user = DB::table('user')->where('id', $request->userid)->first();
    if (!$user) {
        return response()->json([
            'status' => false,
            'message' => 'User not found.'
        ], 200);
    }

    // // Optional: Check if user has enough balance
    // if ($user->wallet < $bet->amount) {
    //     return response()->json([
    //         'status' => false,
    //         'message' => 'Insufficient wallet balance.'
    //     ], 200);
    // }

    // Do the cashout process
    DB::beginTransaction();
    try {
        DB::table('bets')
            ->where('id', $bet->id)
            ->update([
                'win_amount' => $multipliedAmount,
                'multiplier' => $cashout_value,
                'cashout_status' => 1,
                'status' => 1,
                'updated_at' => now()
            ]);

        DB::table('user')
            ->where('id', $request->userid)
            ->increment('wallet', $multipliedAmount);

        DB::commit();

        return response()->json([
            'status' => true,
            'message' => 'Cashout processed successfully.',
            'win_amount' => $multipliedAmount
        ]);
    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json([
            'status' => false,
            'message' => 'Something went wrong during cashout.',
            'error' => $e->getMessage()
        ], 200);
    }
}


//======================winning/loss===============================//  
public function winn_loss(Request $request)
{
    $validator = Validator::make($request->all(), [
        'game_id' => 'required',
        'userid' => 'nullable',
        'status' => 'required',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => false,
            'message' => $validator->errors()->first()
        ], 400);
    }

    $query = DB::table('bets')->where('game_id', $request->game_id);
    if (!empty($request->userid)) {
        $query->where('user_id', $request->userid);
    }
    
    $bet = $query->orderBy('id', 'desc')->first();
    $bet = $query->first(); 
    if (!$bet){
        return response()->json([
            'status' => false,
            'message' => 'Bet not found for this user and game.'
        ], 404);
    }

   
    $newStatus = $request->status == 1 ? 1 : 2;
    DB::table('bets')
        ->where('id', $bet->id)
        ->update([
            'status' => $newStatus,
            'updated_at' => now()
        ]);

    return response()->json([
        'status' => true,
        'message' => $newStatus === 1 ? 'You have won the game!' : 'You have lost the game.',
        'data' => [
            'game_id' => $bet->game_id,
            'user_id' => $bet->user_id,
            'amount' => $bet->amount,
            'multiplier' => $bet->multiplier ?? null,
            'win_amount' => $bet->win_amount ?? 0,
            'status' => $newStatus === 1 ? '1' : '2'
        ]
    ]);
}


//===========================todayBetResult====================================//  
public function today_result(Request $request)
{
    $request->validate([
            'game_id' => 'required|integer',
            'userid' => 'required|integer',
    ]);

    $game_id = $request->game_id;
    $userid = $request->userid; 
    $results = DB::table('bets')
        ->where('game_id', $game_id)
        ->where('user_id', $userid)
        ->select('id','game_id','user_id','amount','win_amount','multiplier','cashout_status','created_at','updated_at')
        ->whereDate('created_at', now()->toDateString()) 
        ->orderByDesc('id')
        ->get();

    return response()->json([
        'status' => true,
        'message' => 'Today\'s bets fetched successfully.',
        'data' => $results,
    ]);
  }
  
  
/////
public function bet_result(Request $request)
{
    $validator = Validator::make($request->all(), [
        'user_id' => 'required'
    ]);

    $validator->stopOnFirstFailure();

    if ($validator->fails()) {
        return response()->json(['success' => false, 'message' => $validator->errors()->first()], 200);
    }

    $user_id = $request->user_id;
    try {
        
        $gamesno=DB::select("SELECT `period_no` FROM `lucky16_betlogs` LIMIT 1;");
         $period=$gamesno[0]->period_no;
          $less_no=$period-1;
        $lastwin_amt=DB::select("SELECT SUM(`win_amount`) as win_amount FROM `bets` WHERE `user_id` = $user_id AND `period_no` = $less_no");
        $win_amt = $lastwin_amt[0]->win_amount ?? 0;
        //dd($lastwin_amt);
      $spinresult = DB::select("SELECT * FROM `lucky16_results` ORDER BY `lucky16_results`.`id` DESC LIMIT 10;");
        if ($spinresult) {
            return response()->json(['success' => true, 'message' => 'Spin result latest data fatch Successfully..!' ,'win_amount' => $win_amt, 'result_16' => $spinresult ]);
        }
        
        return response()->json(['success' => false, 'message' => 'Spin result latest data not found..!']);

    } catch (Exception $e) {
        return response()->json(['error' => 'API request failed: ' . $e->getMessage()], 500);
    }
 }
 


public function getBanners()
{
    $banners = DB::table('banners')
                ->where('status',1)
                ->select('id', 'title', 'image', 'link')
                ->orderBy('id', 'DESC')
                ->get();

    return response()->json([
        'status' => 200,
        'data' => $banners
    ]);
}
public function bet_values()
    {
        $betValues = DB::table('bet_values')
                        ->where('status', 1)
                        ->select('id','value')
                        ->orderBy('value', 'ASC')
                        ->get();

        return response()->json([
            'message'=> 'data fetch success',
            'status' => 200,
            'data' => $betValues
        ]);
    }

}
